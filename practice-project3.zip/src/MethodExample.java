
public class MethodExample {

  // Method that takes two integers as parameters and returns their sum
  public int add(int a, int b) {
    return a + b;
  }

  // Method that takes a string as a parameter and prints it
  public void printMessage(String message) {
    System.out.println(message);
  }

  // Method that takes no parameters and returns nothing
  public void doSomething() {
    System.out.println("Doing something...");
  }

  public static void main(String[] args) {
    MethodExample example = new MethodExample();
    
    // Calling the add method
    int sum = example.add(5, 10);
    System.out.println("Sum: " + sum);
    
    // Calling the printMessage method
    example.printMessage("Hello!");
    
    // Calling the doSomething method
    example.doSomething();
  }
}
