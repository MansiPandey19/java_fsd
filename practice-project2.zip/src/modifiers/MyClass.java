package modifiers;

public class MyClass {
	
	  public int publicVar = 1;
	  
	  
	  private int privateVar = 2;
	  
	  protected int protectedVar = 3;

	 
	  public void publicMethod() {
	    System.out.println("This is a public method.");
	  }

	 
	  private void privateMethod() {
	    System.out.println("This is a private method.");
	  }

	 
	  protected void protectedMethod() {
	    System.out.println("This is a protected method.");
	  }

	

public static void main(String[] args) {
	  MyClass obj = new MyClass();
	  
	  // Accessing public variable and method
	  System.out.println(obj.publicVar);
	  obj.publicMethod();
	  
	 
	  System.out.println(obj.privateVar);
	  obj.privateMethod();
	  
	  // Accessing protected variable and method from the same class
	  System.out.println(obj.protectedVar);
	  obj.protectedMethod();
	}

	class SubClass extends MyClass {
	  public void accessProtected() {
	    // Accessing protected variable and method from the subclass
	    System.out.println(protectedVar);
	    protectedMethod();
	  }
	}
	}































