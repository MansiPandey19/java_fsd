import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample {
    public static void main(String[] args) {
        // Creating a pattern
        Pattern pattern = Pattern.compile("[a-z]+");

        // Creating a matcher
        Matcher matcher = pattern.matcher("Hello, world!");

        // Finding matches
        while (matcher.find()) {
            String match = matcher.group();
            System.out.println("Match found: " + match);
        }
    }
}
