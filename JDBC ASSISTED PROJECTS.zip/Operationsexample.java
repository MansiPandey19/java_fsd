package com.example.operations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Operationsexample {
	
	    public static void main(String[] args) {
	        String url = "jdbc:mysql://localhost:3306/";
	        String username = "root";
	        String password = "root123";

	        try {
	            // Step 1: Establish the connection
	            Connection connection = DriverManager.getConnection(url, username, password);

	            // Step 2: Create a new database
	            String createDatabaseQuery = "CREATE DATABASE mydatabase2";
	            Statement statement = connection.createStatement();
	            statement.executeUpdate(createDatabaseQuery);
	            System.out.println("Database created successfully!");

	            // Step 3: Select the database
	            String selectDatabaseQuery = "USE mydatabase2";
	            statement.executeUpdate(selectDatabaseQuery);
	            System.out.println("Database selected successfully!");

	            // Step 4: Drop the database
	            String dropDatabaseQuery = "DROP DATABASE mydatabase2";
	            statement.executeUpdate(dropDatabaseQuery);
	            System.out.println("Database dropped successfully!");

	            // Step 5: Close the resources
	            statement.close();
	            connection.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}

