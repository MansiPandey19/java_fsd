package com.example.modificationoperations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Modificationoperations {
	public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mydatabase";
        String username = "root";
        String password = "root123";

        try {
            // Step 1: Establish the connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // Step 2: Insertion of a record
            String insertQuery = "INSERT INTO customers (name, email) VALUES (?, ?)";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
            insertStatement.setString(1, "John Doe");
            insertStatement.setString(2, "john.doe@example.com");
            insertStatement.executeUpdate();
            System.out.println("Record inserted successfully!");

            // Step 3: Updation of a record
            String updateQuery = "UPDATE customers SET email = ? WHERE id = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setString(1, "new-email@example.com");
            updateStatement.setInt(2, 1); // Assuming the record with ID 1 exists
            updateStatement.executeUpdate();
            System.out.println("Record updated successfully!");

            // Step 4: Deletion of a record
            String deleteQuery = "DELETE FROM customers WHERE id = ?";
            PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
            deleteStatement.setInt(1, 1); // Assuming the record with ID 1 exists
            deleteStatement.executeUpdate();
            System.out.println("Record deleted successfully!");

            // Step 5: Close the resources
            insertStatement.close();
            updateStatement.close();
            deleteStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

