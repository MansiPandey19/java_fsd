package com.procedureexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.jdbc.CallableStatement;

public class Procedureexample {
	public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mydatabase";
        String username = "root";
        String password = "root123";

        try {
            // Step 1: Establish the connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // Step 2: Create a CallableStatement for the stored procedure
            String storedProcedure = "{CALL add_customer(?, ?)}";
            CallableStatement callableStatement = (CallableStatement) connection.prepareCall(storedProcedure);

            // Step 3: Set the input parameters for the stored procedure
            callableStatement.setString(1, "John Doe");
            callableStatement.setString(2, "john.doe@example.com");

            // Step 4: Execute the stored procedure
            callableStatement.execute();

            System.out.println("Customer added successfully!");

            // Step 5: Close the resources
            callableStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

