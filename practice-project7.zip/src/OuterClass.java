
public class OuterClass {
    private int x = 10;

    public class InnerClass {
        public int getX() {
            System.out.println("Accessing the private variable x of the outer class from the inner class.");
            return x;
        }
    }

    public static void main(String[] args) {
        OuterClass outer = new OuterClass();
        OuterClass.InnerClass inner = outer.new InnerClass();
        System.out.println("Value of x from the inner class: " + inner.getX());
    }
}
