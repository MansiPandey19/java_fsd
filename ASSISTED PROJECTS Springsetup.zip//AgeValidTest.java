package com.example;

import static org.junit.Assert.*;

import org.junit.Test;

public class AgeValidTest {

	@Test
	public void test1() {
		AgeValid valid=new AgeValid();
		
	//	 expected value  actual value
		  assertEquals("right to vote",valid.validateAge(19));
	}

	@Test
	public void test2() {
		AgeValid valid=new AgeValid();
		
	//	 expected value  actual value
		  assertEquals("no right to vote",valid.validateAge(9));
	}

	
}
