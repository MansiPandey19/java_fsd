package Filehandle;

//Define a class "Person"
class Person {
 // Declare class variables
 String name;
 int age;
 
 // Define a constructor
 public Person(String name, int age) {
     this.name = name;
     this.age = age;
 }
 
 // Define a method "sayHello"
 public void sayHello() {
     System.out.println("Hello, my name is " + name + " and I am " + age + " years old.");
 }
}

//Define a subclass "Student" that extends "Person"
class Student extends Person {
 // Declare class variable
 int gradeLevel;
 
 // Define a constructor
 public Student(String name, int age, int gradeLevel) {
     super(name, age);
     this.gradeLevel = gradeLevel;
 }
 
 // Override the method "sayHello"
 public void sayHello() {
     System.out.println("Hello, my name is " + name + ", I am " + age + " years old, and I am in grade " + gradeLevel + ".");
 }
}

//Main class
public class oopconcept {
 public static void main(String[] args) {
     // Create an object of class "Person"
     Person person1 = new Person("Alice", 25);
     person1.sayHello(); // Output: "Hello, my name is Alice and I am 25 years old."
     
     // Create an object of class "Student"
     Student student1 = new Student("Bob", 17, 11);
     student1.sayHello(); // Output: "Hello, my name is Bob, I am 17 years old, and I am in grade 11."
     
     // Use the pillar of inheritance
     Person person2 = new Student("Charlie", 15, 9);
     person2.sayHello(); // Output: "Hello, my name is Charlie, I am 15 years old, and I am in grade 9."
     
     // Use the pillar of polymorphism
     Person[] people = {person1, student1, person2};
     for (Person person : people) {
         person.sayHello(); // Output: "Hello, my name is ... "
     }
     
     // Use the pillar of encapsulation
     student1.gradeLevel = 12;
     student1.sayHello(); // Output: "Hello, my name is Bob, I am 17 years old, and I am in grade 12."
 }
}
