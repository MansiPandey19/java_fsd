package sleepwaitdemo;

public class sleepwait{
    public static void main(String[] args) throws InterruptedException {
        final Object lock = new Object();
        
        // Demonstrate sleep()
        System.out.println("Demonstrating sleep()...");
        for (int i = 0; i < 5; i++) {
            Thread.sleep(1000);
            System.out.println("Slept for " + (i+1) + " seconds.");
        }
        
        // Demonstrate wait()
        System.out.println("\nDemonstrating wait()...");
        Thread t1 = new Thread(() -> {
            synchronized (lock) {
                try {
                    lock.wait();
                    System.out.println("Thread 1 resumed execution.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        
        Thread t2 = new Thread(() -> {
            synchronized (lock) {
                try {
                    Thread.sleep(2000);
                    lock.notify();
                    System.out.println("Thread 2 sent notification.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        
        t1.start();
        t2.start();
    }
}
