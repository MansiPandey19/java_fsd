import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class CollectionExample {

  public static void main(String[] args) {
    // Creating and adding elements to an ArrayList
    ArrayList<String> list = new ArrayList<>();
    list.add("Apple");
    list.add("Banana");
    list.add("Cherry");
    System.out.println("ArrayList: " + list);

    // Creating and adding elements to a HashSet
    HashSet<String> set = new HashSet<>();
    set.add("Apple");
    set.add("Banana");
    set.add("Cherry");
    System.out.println("HashSet: " + set);

    // Creating and adding elements to a HashMap
    HashMap<Integer, String> map = new HashMap<>();
    map.put(1, "Apple");
    map.put(2, "Banana");
    map.put(3, "Cherry");
    System.out.println("HashMap: " + map);

    // Accessing elements of an ArrayList
    System.out.println("First element of ArrayList: " + list.get(0));

    // Accessing elements of a HashSet
    System.out.println("Does HashSet contain Cherry? " + set.contains("Cherry"));

    // Accessing elements of a HashMap
    System.out.println("Value of key 2 in HashMap: " + map.get(2));
  }
}
