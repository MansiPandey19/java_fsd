package Assistedprojects;
public class main {
    public static void main(String[] args) {
        // Create thread using Thread class
        MyThread myThread = new MyThread();
        myThread.start();

        // Create thread using Runnable interface
        MyRunnable MyRunnable = new MyRunnable();
        Thread thread = new Thread(MyRunnable);
        thread.start();
    }
}

