package Assistedprojects;
public class MyThread extends Thread {
    public void run() {
        System.out.println("Thread using Thread class is running.");
    }
}

