package Assistedprojects;
public class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread using Runnable interface is running.");
    }
}

