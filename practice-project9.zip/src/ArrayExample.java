public class ArrayExample {
    public static void main(String[] args) {
        // Creating an array of integers
        int[] numbers = {1, 2, 3, 4, 5};
        System.out.print("Array of numbers: ");
        for (int number : numbers) {
            System.out.print(number + " ");
        }
        System.out.println();

        // Accessing an element in the array
        int firstNumber = numbers[0];
        System.out.println("First number in the array: " + firstNumber);

        // Updating an element in the array
        numbers[0] = 10;
        System.out.print("Array after updating the first element: ");
        for (int number : numbers) {
            System.out.print(number + " ");
        }
        System.out.println();

        // Creating an array of strings
        String[] strings = {"Hello", "World", "!"};
        System.out.print("Array of strings: ");
        for (String string : strings) {
            System.out.print(string + " ");
        }
        System.out.println();
    }
}

