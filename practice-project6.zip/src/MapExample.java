import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapExample {

  public static void main(String[] args) {
    // Creating and adding elements to a HashMap
    Map<Integer, String> hashMap = new HashMap<>();
    hashMap.put(3, "C");
    hashMap.put(1, "A");
    hashMap.put(2, "B");
    System.out.println("HashMap: " + hashMap);

    // Creating and adding elements to a LinkedHashMap
    Map<Integer, String> linkedHashMap = new LinkedHashMap<>();
    linkedHashMap.put(3, "C");
    linkedHashMap.put(1, "A");
    linkedHashMap.put(2, "B");
    System.out.println("LinkedHashMap: " + linkedHashMap);

    // Creating and adding elements to a TreeMap
    Map<Integer, String> treeMap = new TreeMap<>();
    treeMap.put(3, "C");
    treeMap.put(1, "A");
    treeMap.put(2, "B");
    System.out.println("TreeMap: " + treeMap);

    // Accessing elements of a map
    System.out.println("Value of key 2 in HashMap: " + hashMap.get(2));
    System.out.println("Value of key 2 in LinkedHashMap: " + linkedHashMap.get(2));
    System.out.println("Value of key 2 in TreeMap: " + treeMap.get(2));
  }
}
