
public class TypeCastingExample {

  public static void main(String[] args) {
    // Implicit type casting
    int a = 10;
    double b = a;
    System.out.println("Implicit Type Casting: int " + a + " to double " + b);

    // Explicit type casting
    double c = 10.5;
    int d = (int) c;
    System.out.println("Explicit Type Casting: double " + c + " to int " + d);
  }
}
