import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateaadhar',
  templateUrl: './updateaadhar.component.html',
  styleUrls: ['./updateaadhar.component.css']
})
export class UpdateaadharComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
