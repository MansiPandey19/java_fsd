public class ConstructorExample {

  // Default constructor
  public ConstructorExample() {
    System.out.println("Default constructor called.");
  }

  // Parameterized constructor with one parameter
  public ConstructorExample(int a) {
    System.out.println("Parameterized constructor with one parameter called. Value of a: " + a);
  }

  // Parameterized constructor with two parameters
  public ConstructorExample(int a, int b) {
    System.out.println("Parameterized constructor with two parameters called. Value of a: " + a + ", Value of b: " + b);
  }

  public static void main(String[] args) {
    // Creating objects using different constructors
    ConstructorExample obj1 = new ConstructorExample();
    ConstructorExample obj2 = new ConstructorExample(10);
    ConstructorExample obj3 = new ConstructorExample(20, 30);
  }
}
