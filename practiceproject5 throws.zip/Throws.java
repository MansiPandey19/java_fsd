package Filehandle;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Throws {
    public static void main(String[] args) {
        try {
            String filename = "input.txt";
            readFile(filename);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        } finally {
            System.out.println("Program finished.");
        }
    }
    
    public static void readFile(String filename) throws IOException {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            throw e;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.err.println("Error closing file: " + e.getMessage());
                }
            }
        }
    }
}
