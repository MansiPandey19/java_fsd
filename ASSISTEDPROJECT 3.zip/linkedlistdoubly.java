package Practiceproject;

class node {
    int data;
    node previous;
    node next;

    node(int data) {
        this.data = data;
        this.previous = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;

    DoublyLinkedList() {
        this.head = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newnode.previous = temp;
        }
    }

    void traverseForward() {
        if (head == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Node temp = head;
        System.out.println("Traversing Doubly Linked List in forward direction:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    void traverseBackward() {
        if (head == null) {
            System.out.println("Doubly Linked List is empty.");
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        System.out.println("Traversing Doubly Linked List in backward direction:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.previous;
        }
        System.out.println();
    }
}

public class linkedlistdoubly {
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);

        list.traverseForward();
        list.traverseBackward();
    }
}
