package Practiceproject;

public class matrixmultiplication{  
public static void main(String args[]){  

int a[][]={{1,21,17},{4,5,2},{3,30,83}};    
int b[][]={{14,11,91},{90,21,67},{63,23,3}};    
    
  
int c[][]=new int[3][3];  

for(int i=0;i<3;i++){    
for(int j=0;j<3;j++){    
c[i][j]=0;      
for(int k=0;k<3;k++)      
{      
c[i][j]+=a[i][k]*b[k][j];      
}
System.out.print(c[i][j]+" ");  
}
System.out.println();
}    
}}  