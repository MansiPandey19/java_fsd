package Practiceproject;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    LinkedList() {
        this.head = null;
    }

    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    void delete(int key) {
        Node prev = null;
        Node curr = head;

        if (curr != null && curr.data == key) {
            head = curr.next;
            return;
        }

        while (curr != null && curr.data != key) {
            prev = curr;
            curr = curr.next;
        }

        if (curr == null) {
            System.out.println("Key not found in the list.");
            return;
        }

        prev.next = curr.next;
    }

    void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class firstoccurence {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(50);

        System.out.println("Original Linked List:");
        list.display();

        int key = 30;
        list.delete(key);

        System.out.println("Linked List after deleting the first occurrence of " + key + ":");
        list.display();
    }
}
