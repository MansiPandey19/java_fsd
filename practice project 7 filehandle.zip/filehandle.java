package FileHandling;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class filehandle{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Creating a new file
        try {
            File file = new File("myfile.txt");
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
        }

        // Writing to a file
        try {
            FileWriter writer = new FileWriter("myfile.txt");
            writer.write("Hello, world!\n");
            writer.write("This is a test file.\n");
            writer.close();
            System.out.println("Data written to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
        }

        // Reading from a file
        try {
            File file = new File("myfile.txt");
            Scanner reader = new Scanner(file);
            System.out.println("Contents of the file:");
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                System.out.println(line);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("An error occurred while reading from the file.");
        }

        // Updating a file
        try {
            FileWriter writer = new FileWriter("myfile.txt", true);
            writer.write("This is some new data.\n");
            writer.close();
            System.out.println("Data updated in the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
        }

        // Deleting a file
        try {
            File file = new File("myfile.txt");
            if (file.delete()) {
                System.out.println("File deleted: " + file.getName());
            } else {
                System.out.println("File not found.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred while deleting the file.");
        }
    }
}



